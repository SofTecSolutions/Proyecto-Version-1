package gestionClientes.modelo;

import general.modelo.IPersona;

public interface ICliente extends IPersona {
	public String getNumTarjeta();
	public int getPuntos();
	public int getDescuento();

}
