package gestionClientes.modelo;

import general.exception.*;

public class Tarjeta {
	private String numTarjeta;
	private int puntos;
	
	public Tarjeta(String numTarjeta) {
		this.numTarjeta = numTarjeta;
		this.puntos = 0;
	}
	
	protected String getNumTarjeta() {
		return numTarjeta;
	}
	protected int getPuntos() {
		return puntos;
	}
	protected void setPuntos(int puntos) throws NegativeException {
		if(puntos >= 0)
			this.puntos = puntos;
		else
			throw new NegativeException();
	}

}
