package gestionClientes.modelo;

import java.sql.SQLException;

import general.exception.*;
import general.modelo.Direccion;
import general.modelo.IDireccion;
import general.modelo.Persona;

public class Cliente extends Persona implements ICliente {
	private Tarjeta tarjeta;
	
	private final int LENGHT_NUM_TARJETA = 8;
	private final int MAX_CLIENTES = (int) Math.pow(10, LENGHT_NUM_TARJETA);
	
	//Metodos de cliente
	
	public Cliente() throws SQLException{
		this.tarjeta = new Tarjeta(generarNumTarjeta());
	}
	
	protected Cliente(String numTarjeta, Persona datosPersonales) {
		super(datosPersonales);
		this.tarjeta = new Tarjeta(numTarjeta);
	}
	
	public Cliente(Cliente cliente) throws NegativeException {
		//datos de la tarjeta 
		this.tarjeta = new Tarjeta(cliente.getNumTarjeta());
		this.tarjeta.setPuntos(cliente.getPuntos());
		
		//Datos de persona
		primerNombre = cliente.getPrimerNombre();
		segundoNombre = cliente.getSegundoNombre();
		apellidoPaterno = cliente.getApellidoPaterno();
		apellidoMaterno = cliente.getApellidoMaterno();
		edad = cliente.getEdad();
		numeroTelfono = cliente.getNumeroTelefono();
		//Datos de direccion
		direccion = new Direccion(cliente.direccion);
	}
	public void setPuntos(int puntos) throws NegativeException {
		if(edad>= 60 && puntos<40)
			this.tarjeta.setPuntos(40);
		else
			this.tarjeta.setPuntos(puntos);
	}
	
	private String generarNumTarjeta() throws SQLException{
		String numTargeta = "";
		do {
			int numTarjetaI = (int) (Math.random() * MAX_CLIENTES);
			
			if(numTarjetaI >= MAX_CLIENTES)
				numTarjetaI = MAX_CLIENTES - 1;
			
			numTargeta = "" + numTarjetaI;
			
			while(numTargeta.length() < LENGHT_NUM_TARJETA) {
				numTargeta = "0" + numTargeta;
			}
		}while(ClienteDB.existe(numTargeta));
		return numTargeta;
		
	}
	
	//Metodos de IClientes 
	
	public String getNumTarjeta() {
		return tarjeta.getNumTarjeta();
	}
	public int getPuntos() {
		return tarjeta.getPuntos();
	}
	
	public int getDescuento() {
		int descuento = 0;
		
		if(tarjeta.getPuntos()>=10 && tarjeta.getPuntos()<20)
			descuento = 10;
		if(tarjeta.getPuntos()>=20 && tarjeta.getPuntos()<30)
			descuento = 20;
		if(tarjeta.getPuntos()>=30 && tarjeta.getPuntos()<40)
			descuento = 30;
		if(tarjeta.getPuntos()>=40 && tarjeta.getPuntos()<50)
			descuento = 40;
		if(tarjeta.getPuntos()>=50 && tarjeta.getPuntos()<60)
			descuento = 50;
		if(tarjeta.getPuntos()>=60 && tarjeta.getPuntos()<70)
			descuento = 60;
		if(tarjeta.getPuntos()>=70 && tarjeta.getPuntos()<80)
			descuento = 70;
		if(tarjeta.getPuntos()>=80)
			descuento = 80;
		
		return descuento;
		
	}
	
	//Metodos de persona 
	
	public String getPrimerNombre() {
		return primerNombre;
	}
	
	public String getSegundoNombre() {
		return segundoNombre;
	}
	
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	
	public int getEdad() {
		return edad;
	}
	
	public String getNumeroTelefono() {
		return numeroTelfono;
	}
	
	public IDireccion getDireccion() {
		return direccion;
	}
	
	public String nombreCompleto() {
		String s = "";
		if(!apellidoPaterno.equals(""))
			s += apellidoPaterno;
		if(!apellidoMaterno.equals(""))
			s += apellidoMaterno;
		if(!primerNombre.equals(""))
			s += " " + primerNombre;
		if(!segundoNombre.equals(""))
			s += " " + segundoNombre;
		return s;
	}	
}
