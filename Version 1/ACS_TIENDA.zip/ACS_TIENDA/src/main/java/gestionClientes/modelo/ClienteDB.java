package gestionClientes.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import general.exception.CaracterExcepcion;
import general.exception.CeroException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import general.modelo.AdminBD;
import general.modelo.Persona;
import general.modelo.PersonaDB;

public class ClienteDB {
	
	public static boolean existe(String numTarjeta) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			try {
				st = conexion.createStatement();
				comSQL = "select * from cliente where num_tarjeta = '" + numTarjeta + "';";
				rs = st.executeQuery(comSQL);
				while(rs.next()) {
					cont += 1;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conexion.close();
			} catch (SQLException e2) {
				// TODO: handle exception
			}
		}
	}
	if(cont > 0)
		respuesta = true;
	return respuesta;
  }
	
  public static Optional<Cliente> buscar(String numTarjeta) throws SQLException, PalabraException, CaracterExcepcion, LengthException, CeroException, RangoException, NegativeException {
	  Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Cliente cliente = null;
		Optional<Persona> persona = null;
		
		int puntos = 0;
		String personaId = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * froms cliente where num_tarjeta = '" + numTarjeta + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				puntos = rs.getInt("puntos");
				personaId = rs.getString("persona");
				
				persona = PersonaDB.buscar(personaId);
				
				if(persona.isPresent()) {
					cliente = new Cliente(numTarjeta, persona.get());
					cliente.setPuntos(puntos);
				}
			}
			conexion.close();
		}
		
		return Optional.ofNullable(cliente);
  }
  
  public static boolean actualizar(Cliente cliente) throws SQLException {
	    Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st =conexion.createStatement();
			
			comSQL = "update cliente set puntos =" + cliente.getPuntos() + "where num_tarjeta = '" + cliente.getNumTarjeta() + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 1) {
				if(PersonaDB.actualizar(cliente, cliente.getNumTarjeta())) {
					respuesta = true;
					conexion.commit();
				}else
					conexion.rollback();
			}else conexion.rollback();
			
			conexion.close();
		}
		
		return respuesta;
  }
  
  public static boolean actualizarPuntos(Cliente cliente) throws SQLException {
	  Connection conexion;
	  String comSQL;
	  Statement st;
	  int cont = 0;
	  boolean respuesta = false;
	  
	  conexion = AdminBD.conectar();
	  if(conexion != null) {
		  st = conexion.createStatement();
		  
		  comSQL = "update cliente set puntos = " + (cliente.getPuntos() + 1) + "where num_tarjeta = '" + cliente.getNumTarjeta() + "';";
		  cont += st.executeUpdate(comSQL);
		  
		  if(cont == 1)
			  respuesta = true;
		  
		  conexion.close();
	  }
	  
	  return respuesta;
  }
  
  public static boolean eliminar(String numTarjeta) throws SQLException {
	    Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "delete from cliente where num_tarjeta = '" + numTarjeta + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from persona where id = '" + numTarjeta + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from direccion where id = '" + numTarjeta + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont == 3) {
				respuesta = true;
				conexion.commit();
			}else
				conexion.rollback();
			
			conexion.close();
		}
		return respuesta;
    }  
  	
  	public static boolean guardar (Cliente cliente) throws SQLException{
  		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			if(PersonaDB.guardar(cliente, cliente.getNumTarjeta())) {
				st = conexion.createStatement();
				comSQL = "insert into cliente values ('" + cliente.getNumTarjeta() + "' , " + cliente.getPuntos() +
						 " , '" + cliente.getNumTarjeta() + "');";
				cont += st.executeUpdate(comSQL);
				
				if(cont == 1)
					respuesta = true;
			}
			
			conexion.close();
		}
		
		return respuesta;
  	}
  	
  	public static List<Cliente> buscarClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException {
  		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Cliente> clientes = new ArrayList<Cliente>();
		Cliente cliente = null;
		Optional<Persona> persona = null;
		
		int puntos = 0;
		String personaId = "";
		String numTarjeta = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from cliente; ";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				puntos = rs.getInt("puntos");
				personaId = rs.getString("persona");
				numTarjeta = rs.getString("num_tarjeta");
				
				persona = PersonaDB.buscar(personaId);
				
				if(persona.isPresent()) {
					cliente = new Cliente(numTarjeta, persona.get());
					cliente.setPuntos(puntos);
					
						clientes.add(cliente);
				}
			}
			conexion.close();
		}
		return clientes;
  	}
  
}
