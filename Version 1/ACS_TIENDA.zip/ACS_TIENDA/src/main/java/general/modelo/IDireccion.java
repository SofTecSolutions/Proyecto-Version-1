package general.modelo;

public interface IDireccion {
	public String getCalle();
	public String getNumExterior();
	public String getNumInterior();
	public String getColonia();
	public String getCiudad();
	public String getEstado();
	public String getCodigoPostal();
	public String direccionCompleta();

}
