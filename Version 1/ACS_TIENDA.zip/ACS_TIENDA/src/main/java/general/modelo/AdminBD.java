package general.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import general.exception.CaracterExcepcion;
import general.exception.LengthException;
import general.exception.PalabraException;

public class AdminBD {
	
	public static Connection conectar() throws SQLException{
		Connection conexion = null;
		String url;
		String password;
		String usuario;
		
		url = "jdbc:postgresql://localhost:5432/TiendaACS";
		usuario = "postgres";
		password = "p057gr35";

		
		conexion = DriverManager.getConnection(url, usuario, password);
		
		return conexion;
	}
	
	private static boolean existe() throws SQLException {
		Connection  conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "select *from Tienda where id = 'ADMIN';";
			rs = st.executeQuery(comSQL);
			while(rs.next()) {
				cont +=1;
			}
			conexion.close();
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}
	
	public static Tienda cargar() throws SQLException, PalabraException, CaracterExcepcion, LengthException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Tienda tienda = null;
		
		//Tienda
		String Nombre;
		String RFC; 
		String numeroTelefono;
		Optional<Direccion> direccion;
		String password;
		
		if(!existe())
			creaAdmin();
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from tienda where id = 'ADMIN';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()){
				Nombre = rs.getString("nombre");
				RFC = rs.getString("rfc");
				numeroTelefono = rs.getString("numero_telefono");
				password = rs.getString("password");
				
				direccion = DireccionDB.buscar("ADMIN");
				
				if(direccion.isPresent()) {
					tienda = new Tienda();
					tienda.setNombre(Nombre);
					tienda.setNumeroTelefono(numeroTelefono);
					tienda.setRFC(RFC);
					tienda.setPassword(password);
					tienda.setDireccion(direccion.get());
		
				}
			}
			conexion.close();
		}
		
		return tienda;
	}
	
	private static void creaAdmin()throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "insert into direccion values ('ADMIN' , 'PROLONGACIÓN SAN ISIDRO' , '152' , 'SN' , "
					+ "'SAN LORENZO TEZONCO' , 'ALCALDIA IZTAPALAPA' , 'CDMX' , '09790');";
			st.executeUpdate(comSQL);
			
			comSQL ="insert into tienda values ('ADMIN' , 'TIENDA ACS'" +
					", 'ASC290923UACM' , '5538199082' , 'ADMIN' , 'TiendaACS' );";
			st.executeUpdate(comSQL);
			
			conexion.close();
		}
		
	}
	
}
