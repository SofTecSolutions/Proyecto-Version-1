package general.modelo;

public interface IPersona {
	public String getPrimerNombre();
	public String getSegundoNombre();
	public String getApellidoPaterno();
	public String getApellidoMaterno();
	public int getEdad();
	public String getNumeroTelefono();
	public IDireccion getDireccion();
	public String nombreCompleto();

}
