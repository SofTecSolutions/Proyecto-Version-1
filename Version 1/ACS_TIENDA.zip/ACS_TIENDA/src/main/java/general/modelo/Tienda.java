package general.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import general.exception.CaracterExcepcion;
import general.exception.CeroException;
import general.exception.FechaException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import gestionArticulos.modelo.Articulo;
import gestionArticulos.modelo.ArticuloDB;
import gestionArticulos.modelo.IArticulo;
import gestionClientes.modelo.Cliente;
import gestionClientes.modelo.ClienteDB;
import gestionClientes.modelo.ICliente;
import gestionVendedores.modelo.*;

public class Tienda implements ITienda {
	private String nombre;
	private String RFC;
	private String numeroTelefono;
	private Direccion direccion;
	private String password;
	private Map<String, Vendedor> vendedores;
	private Map<String, Articulo> articulos;
	private Map<String, Cliente> clientes;
	
	//Metodos de tienda
	
	public Tienda() {
		this.vendedores = new HashMap<>();
		this.articulos = new HashMap<>();
		this.clientes = new HashMap<>();	
	}
	
	public Tienda(Tienda tienda) {
		vendedores = new HashMap<>();
		this.articulos = new HashMap<>();
		this.clientes = new HashMap<>();
		this.nombre = tienda.nombre;
		this.RFC = tienda.RFC;
		this.numeroTelefono = tienda.numeroTelefono;
		this.password = tienda.password;
		this.direccion = new Direccion(tienda.direccion);
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setRFC(String rfc) {
		this.RFC = rfc;
	}
	
	public void setNumeroTelefono(String numeroTelefono ) {
		this.numeroTelefono = numeroTelefono;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setDireccion(Direccion direccion) {
		this.direccion = new Direccion(direccion);
	}
	
	private void cargarVendedoresCorreo() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException,RangoException {
		this.vendedores = new HashMap<>();
		List<Vendedor> vendedores = VendedorBD.buscarVendedores();
		for(Vendedor v: vendedores) {
			this.vendedores.put(v.getCorreo(), v);
		}
	}
	
	private void cargarVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException {
		this.vendedores = new HashMap<>();
		List<Vendedor> vendedores = VendedorBD.buscarVendedores();
		for(Vendedor v: vendedores ) {
			this.vendedores.put(v.getNumEmpleado(), v);
		}
	}
	
	private void cargarArticulos() throws SQLException, PalabraException, FechaException, NegativeException {
		this.articulos = new HashMap<>();
		List<Articulo> articulos = ArticuloDB.buscarArticulo();
		for(Articulo a: articulos) {
			this.articulos.put(a.getId(), a);
		}
	}
	private void cargarClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException {
		this.clientes = new HashMap<>();
		List<Cliente> clientes = ClienteDB.buscarClientes();
		for(Cliente c: clientes) {
			this.clientes.put(c.getNumTarjeta(), c);
		}
	}
	
	//metodo de ITienda
	
	@Override
	public String getNombre() {
		
		return nombre;
	}
	@Override
	public String getRFC() {
		
		return RFC;
	}
	@Override
	public String getNumeroTelefono() {
		
		return numeroTelefono;
	}
	@Override
	public String getPassword() {
		
		return password;
	}
	@Override
	public IDireccion getDireccion() {
		return direccion;
	}
	@Override
	public Optional<IVendedor> obtenerVendedor(String correo, String password) throws SQLException, LengthException, PalabraException, CaracterExcepcion, RangoException, NegativeException, CeroException {
		cargarVendedoresCorreo();
		Optional<Vendedor> vendedor = Optional.ofNullable(this.vendedores.get(correo));
		IVendedor result = null;
		
		if(vendedor.isPresent()) {
			if(vendedor.get().getPassword().equals(password)) {
				result = (IVendedor) vendedor.get();
			}
		}
		return Optional.ofNullable(result);
	}
	
	public Iterator<IVendedor> getVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException {
		cargarVendedores();
		List<IVendedor> vendedores = new ArrayList<IVendedor>();
		for(Vendedor v: this.vendedores.values()) {
			vendedores.add((IVendedor) v);
		}
		return vendedores.iterator();
	}
	
	public Iterator<ICliente> getClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException {
		cargarClientes();
		List<ICliente> clientes = new ArrayList<ICliente>();
		for(Cliente c: this.clientes.values()) {
			clientes.add(c);
		}
		return clientes.iterator();
	}
	public Iterator<IArticulo> getArticulos() throws SQLException, PalabraException, FechaException, NegativeException {
		cargarArticulos();
		List<IArticulo> articulos = new ArrayList<IArticulo>();
		for(Articulo a: this.articulos.values()) {
			articulos.add(a);
		}
		return articulos.iterator();
	}
}
