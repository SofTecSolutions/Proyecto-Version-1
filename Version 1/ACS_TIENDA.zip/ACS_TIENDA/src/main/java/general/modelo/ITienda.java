package general.modelo;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.Optional;

import general.exception.CaracterExcepcion;
import general.exception.CeroException;
import general.exception.FechaException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import gestionArticulos.modelo.IArticulo;
import gestionClientes.modelo.ICliente;
import gestionVendedores.modelo.IVendedor;

public interface ITienda {
	public String getNombre();
	public String getRFC();
	public String getNumeroTelefono();
	public String getPassword();
	public IDireccion getDireccion();
	public Optional<IVendedor> obtenerVendedor(String correo, String password) throws SQLException, LengthException,PalabraException, CaracterExcepcion, RangoException, NegativeException, CeroException;
	public Iterator<IVendedor> getVendedores() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException;
	public Iterator<ICliente> getClientes() throws SQLException, LengthException, NegativeException, PalabraException, CaracterExcepcion, CeroException, RangoException;
	public Iterator<IArticulo> getArticulos() throws SQLException, PalabraException, FechaException, NegativeException;
	

}
