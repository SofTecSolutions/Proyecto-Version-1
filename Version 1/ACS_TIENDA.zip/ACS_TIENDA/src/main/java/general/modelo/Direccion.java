package general.modelo;

import general.exception.*;

public class Direccion implements IDireccion{
	private String calle;
	private String numExterior;
	private String numInterior;
	private String colonia;
	private String ciudad;
	private String estado;
	private String codigoPostal;
	
	//Metodos para direccion
	
	public Direccion() {
		calle = "";
		numExterior = "";
		numInterior = "";
		colonia = "";
		ciudad = "";
		estado = "";
		codigoPostal = "";
	}
	
	public Direccion(IDireccion direccion) {
		calle = direccion.getCalle();
		numExterior = direccion.getNumExterior();
		numInterior = direccion.getNumInterior();
		colonia = direccion.getColonia();
		ciudad = direccion.getCiudad();
		estado = direccion.getEstado();
		codigoPostal = direccion.getCodigoPostal();
	}
	
	public void setCalle(String calle) throws PalabraException{
		if(calle.matches("^[A-ZÁÉÍÓÚÜÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.calle=calle;
		else
			throw new PalabraException();
	}
	public void setNumExterior(String numExterior) throws CaracterExcepcion{
		if(numExterior.matches("^[0-9]{1,4}"))
			this.numExterior = numExterior;
		else 
			throw new CaracterExcepcion();
	}
	public void setNumInterior(String numInterior) throws CaracterExcepcion{
		if(numInterior.matches("[A-Z]{0,3}[0-9]{0,4}"))
			this.numInterior = numInterior;
		else 
			throw new CaracterExcepcion();
	}
	public void setColonia(String colonia) throws PalabraException{
		if(colonia.matches("^[A-ZÁÉÍÓÚÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.colonia = colonia;
		else
			throw new PalabraException();
	}
	public void setCiudad(String ciudad) throws PalabraException{
		if(ciudad.matches("^[A-ZÁÉÍÓÚÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.ciudad = ciudad;
		else
			throw new PalabraException();
	}
	public void setEstado(String estado) throws PalabraException{
		if(estado.matches("^[A-ZÁÉÍÓÚÑ]{1,50}([\\s][A-ZÁÉÍÓÚÑ]{1,50}){0,9}"))
			this.estado = estado;
		else
			throw new PalabraException();
	}
	public void setCodigoPostal(String codigoPostal) throws CaracterExcepcion, LengthException{
		if(codigoPostal.matches("^[0-9]{5}"))
			this.codigoPostal = codigoPostal;
		else if(codigoPostal.matches("^[0-9]{0,4}")|| codigoPostal.matches("^[0-9]{6,}"))
			throw new LengthException();
		else 
			throw new CaracterExcepcion();
	}
	
	//Metodos para IDireccion 
	@Override
	public String getCalle() {
		return calle;
	}
	@Override
	public String getNumExterior() {
		return numExterior;
	}
	@Override
	public String getNumInterior() {
		return numInterior;
	}
	@Override
	public String getColonia() {
		return colonia;
	}
	@Override
	public String getCiudad() {
		return ciudad;
	}
	@Override
	public String getEstado() {
		return estado;
	}
	@Override
	public String getCodigoPostal() {
		return codigoPostal;
	}
	
	@Override
	public String direccionCompleta() {
		String d = "";
		
		if(!calle.equals(""))
			d += "CALLE" + calle;
		if(!numExterior.equals(""))
			d += " " + numExterior;
		if(!numInterior.equals(""))
			d += " INT " + numInterior;
		if(!colonia.equals(""))
			d += ", " + colonia;
		if(!ciudad.equals(""))
			d += ", " + ciudad;
		if(!codigoPostal.equals(""))
			d += ", CP. " + codigoPostal;
		if(!estado.equals(""))
			d += ", " + codigoPostal;
		if(d.equals(""))
			d += "S/D";
		else
			d += ", MEXICO";
		return d;
	}

}
