package general.exception;

public class FechaException extends Exception{
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	public FechaException() {
		super(Mensajes.FECHA.getMessage());
	}
}
