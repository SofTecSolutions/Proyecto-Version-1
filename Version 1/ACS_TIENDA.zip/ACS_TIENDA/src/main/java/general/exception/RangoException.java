package general.exception;

public class RangoException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public RangoException() {
		super(Mensajes.RANGO.getMessage());
	}

}
