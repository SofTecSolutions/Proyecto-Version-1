package general.exception;

public class NegativeException extends Exception {
	
	/**
	 * 
	 */
	public static final long serialVersionUID = 1L;
	
	public NegativeException() {
		super(Mensajes.NEGATIVO.getMessage());
	}
}
