package general.exception;

public class CeroException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CeroException() {
		super(Mensajes.CERO.getMessage());
	}

}
