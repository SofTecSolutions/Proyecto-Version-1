package general.exception;

public class ProductoException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ProductoException() {
		super(Mensajes.PRODUCTO.getMessage());
	}

}
