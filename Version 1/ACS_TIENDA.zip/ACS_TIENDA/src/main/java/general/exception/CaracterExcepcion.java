package general.exception;

public class CaracterExcepcion extends Exception{
	
	
	private static final long serialVersionUID =1L;
	
	public CaracterExcepcion() {
		super(Mensajes.CARACTER.getMessage());
	}

}
