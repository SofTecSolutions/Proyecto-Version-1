package general.exception;

public enum Mensajes {
	PALABRA("Formato invalido"),
	NEGATIVO("No puede ser meno a cero"),
	CARACTER("Caracter invalido"),
	FECHA("Fecha invalida"),
	CERO("No puede ser cero"),
	RANGO("Fuera de Rango"),
	LENGTH("Numero de caracteres invalido"),
	PRODUCTO("Producto no encontrado");
	
	private String message;
	
	private Mensajes(String message) {
		this.message = message;
	}
	public String getMessage() {return message;}
}
