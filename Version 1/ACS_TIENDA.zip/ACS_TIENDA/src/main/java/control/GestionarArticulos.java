package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;
import java.util.List;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import general.exception.FechaException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.modelo.Tienda;
import general.modelo.ITienda;
import gestionArticulos.modelo.Articulo;
import gestionArticulos.modelo.ArticuloDB;

/**
 * Servlet implementation class GestionarArticulos
 */
@WebServlet("/GestionarArticulos")
public class GestionarArticulos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarArticulos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        ITienda tienda = (ITienda) session.getAttribute("tienda");
        if(tienda == null)
        	tienda = new Tienda();
        
        String[] message;
        String mensaje = "";
        List<String> list;
        
        String boton = request.getParameter("boton");
        
        System.out.println(boton);
        /* BN - BOTÓN QUE ENVIA A NUEVO ARTICULO
         * BA - BOTÓN QUE ENVIA A ACTUALIZAR ARTICULO
         * BD - BOTÓN QUE ENVIA A INFO ARTICULO
         * BE - BOTÓN QUE ENVIA A ELIMINAR ARTICULO
         * 
         * DA - ENVIA DE INFO ARTICULO A ACTUALIZAR ARTICULO
         * DE - ENVIA DE INFO ARTICULO A ELIMINAR ARTICULO
         * DM - FUNCION AGREGAR EXISTENCIA
         * 
         * NA - FUNCION NUEVO ARTICULO
         * CNA - FUNCION CONTINUAR CREACION ARTICULO
         * AA - FUNCION ACTUALIZAR ARTICULO
         * CAA - FUNCION CONTINUAR ACTUALIZACION ARTICULO
         * EA - FUNCION ELIMINAR ARTICULO
         * 
         * CC - ENVIA/REGRESA A INICIO (index.jsp) 
         * C - ENVIA/REGRESA A GESTIONAR ARTICULO
         **/
        if(boton != null)
        	switch (boton) {
        	//botones del jsp GestionarArticulos
        	case "BN":
        		message = new String[4];
        		for(int i=0; i<message.length; i++)
        			message[i] = "";
        		request.setAttribute("message", message);
        		request.getRequestDispatcher("GestionArticulos/NuevoArticulo.jsp").forward(request, response);
        		break;
        	case "BD":
        		if(buscarArticulo(request, response, tienda, session)) {
        			request.getRequestDispatcher("GestionArticulo/InfoArticulo.jsp").forward(request, response);
        		}else {
        			regresar(request, response, tienda, session);
        		}
        		break;
        	case "BA":
        		if(buscarArticulo(request, response, tienda, session)) {
        			message = new String[4];
        			for(int i = 0; i<message.length; i++)
        				message[i] = "";
        			request.setAttribute("message", message);
        			request.getRequestDispatcher("GestionArticulos/ActualizarArticulos.jsp").forward(request, response);
        		}else {
        			regresar(request, response, tienda, session);
        		}
        		break;
        	
        	case "BE":
        		if(buscarArticulo(request, response, tienda, session)) {
        			request.getRequestDispatcher("GestionArticulo/EliminarArticulo.jsp").forward(request, response);
        		}else {
        			regresar(request, response, tienda, session);
        		}
        		break;
        		
        		//Botones de InfoArticulos
        	case "DA":
        		message = new String[4];
        		for(int i = 0; i<message.length; i++)
        			message[i] = "";
        		request.setAttribute("message", message);
        		request.getRequestDispatcher("GestionArticulos/ActualizarArticulo.jsp").forward(request, response);
        		break;
        	case "DE":
        		request.getRequestDispatcher("GestionArticulos/EliminarArticulo.jsp").forward(request, response);
        		break;
        		
        	case "DM":
        		actualizarExistencia(request, response, tienda, session);
        		break;
        		
        	//Botones de accion para administrar los Articulos
        	case "NA":
        		nuevoArticuloContinuar(request, response, tienda, session);
        		break;
        	
        	case "CNA":
        		nuevoArticulo(request,response, tienda, session);
        		break;
        		
        	case "AA":
        		actualizarArticuloContinuar(request, response, tienda, session);
        		break;
        	
        	case "CAA":
        		actualizarArticulo(request, response, tienda, session);
        		break;
        	
        	case "EM":
        		eliminarArticulo(request, response, tienda, session);
        		break;
        		
        	
        	
        	//Botones para regresar
        		
        	case "C": 
        		regresar(request, response, tienda, session);
        		break;
        	
        	default:
        		break;
        	}
        else {
        	regresar(request, response, tienda, session);
        }
	}
	
	
	//Metodos para gestionar Articulos
	protected boolean buscarArticulo(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException {
		boolean result = false;
		String message = "";
		String id = request.getParameter("id");
		if(id != null) {
			try {
				Optional<Articulo> articulo = ArticuloDB.buscar(id);
				if(articulo.isPresent()) {
					session.setAttribute("articulo", articulo.get());
					result = true;
				}else {
					String mensaje = "Articulo no encontrado";
					request.setAttribute("message", mensaje);
					regresar(request, response, tienda, session);
				}
			} catch (SQLException |NegativeException | PalabraException | FechaException e) {
				e.printStackTrace();
				String messages = "Ha ocurrido un problema de conexion";
				request.setAttribute("message", messages);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else {
			message = "No se pudo encontrar al articulo";
			request.setAttribute("message", message);
			regresar(request, response, tienda, session);
		}
		return result;
	}
	
	protected void regresar(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException {
		try {
			session.setAttribute("articulos", tienda.getArticulos());
			request.getRequestDispatcher("GestionArticulos/GestionArticulos.jsp").forward(request, response);
		} catch (SQLException | NegativeException | PalabraException | FechaException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexion";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	
	protected void nuevoArticulo(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException {
		boolean crear = true;
		String[] message = new String[4];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Articulo articulo = null;
		
		String nombre = request.getParameter("NombreArticulo");//0
		double precio = -1;
		try {
			precio = Double.parseDouble(request.getParameter("Precio"));//1
		} catch (NumberFormatException e) {
			message[2] = "No ha ingresado una cantidad";
		}
		
		//Creamos el articulo
		try {
			articulo = new Articulo();
			try {
				articulo.setNombre(nombre.toUpperCase());
			} catch (PalabraException e) {
				message[0] = e.getMessage();
			}
			try {
				articulo.setPrecio(precio);
			}catch (NegativeException e) {
				message[1] = e.getMessage();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexion";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			
		}
		
		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {
			session.setAttribute("articulo", articulo);
			regresar(request, response, tienda, session);
		}
	}
	
	protected void nuevoArticuloContinuar(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException{
		Articulo articulo = (Articulo) session.getAttribute("articulo");
		
		try {
			if(ArticuloDB.guardar(articulo)) {
				String message = "Se ha guardado el articulo con el id: " + articulo.getId();
				request.setAttribute("message", message);
				regresar(request, response, tienda, session);
				
			}else {
				String message = "No se pudo guardar el articulo";
				request.setAttribute("message", message);
				regresar(request, response, tienda, session);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexion";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	
	protected void actualizarArticulo(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException{
		boolean crear = true;
		String[] message = new String[4];
		for(int i = 0; i<message.length; i++)
			message[i] = "";
		Articulo articulo = new Articulo((Articulo) session.getAttribute("articulo"));
		
		String nombre = request.getParameter("NombreArticulo");//0
		double precio = -1;
		String precioS = request.getParameter("Precio");
		if(!precioS.equals("")) {
			try {
				precio = Double.parseDouble(precioS);//1
			} catch (NumberFormatException e) {
				message[2] = "No se ha ingresado una edad";
			}
		}
		
		//Creamos al articulo
		try {
			if(!nombre.equals(""))
				articulo.setNombre(nombre.toUpperCase());
		} catch (PalabraException e) {
			if(!precioS.equals(""))
				message[2] = e.getMessage();
		}
		
		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {
			session.setAttribute("articulo", articulo);
			regresar(request, response, tienda, session);
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionArticulos/ActualizarArticulo.jsp").forward(request, response);
		}
	}
	
	protected void actualizarArticuloContinuar(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws IOException, ServletException {
		Articulo articulo = (Articulo) session.getAttribute("articulo");
		
		try {
			if(ArticuloDB.actualizar(articulo)) {
				String message = "Se ha actualizado el articulo con el id: " + articulo.getId();
				request.setAttribute("message", message);
				regresar(request, response, tienda, session);
				
			}else {
				String message = "No se pudo crear el articulo";
				request.setAttribute("message", message);
				regresar(request, response, tienda, session);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	protected void actualizarExistencia(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException{
		Articulo articulo = new Articulo((Articulo) session.getAttribute("articulo"));
		String message = "";
		String numS = request.getParameter("NumArticulos");
		int num = 0; 
		try {
			num = Integer.parseInt(numS);
		}catch (NumberFormatException e) {
			message = "Ingrese un numero entero";
		}
		
		num += articulo.getNumeroArticulos();
		
		try {
			articulo.setNumArticulos(num);
		}catch (NegativeException e) {
			message = e.getMessage();
		}
		
		try {
			ArticuloDB.actualizarExistencia(articulo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("message", message);
		session.setAttribute("articulo", articulo);
		request.getRequestDispatcher("GestionArticulos/InfoArticulo.jsp").forward(request, response);
	}
	
	protected void eliminarArticulo(HttpServletRequest request, HttpServletResponse response, ITienda tienda, HttpSession session) throws ServletException, IOException{
		Articulo articulo = (Articulo) session.getAttribute("articulo");
		String message;
		
		try {
			if(ArticuloDB.eliminar(articulo.getId())) {
				message = "Se ha eliminado correctamente al medicamento con id: " + articulo.getId();
				request.setAttribute("message", message);
				regresar(request, response, tienda, session);
			}else {
				message = "No se pudo eiminar el articulo";
				request.setAttribute("message", message);
				regresar(request, response, tienda, session);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	


}
