package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import general.exception.CaracterExcepcion;
import general.exception.CaracterExcepcion;
import general.exception.CeroException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.RangoException;
import general.modelo.Direccion;
import general.modelo.Tienda;
import general.modelo.ITienda;
import gestionClientes.modelo.Cliente;
import gestionClientes.modelo.ClienteDB;


/**
 * Servlet implementation class GestionarClientesVendedor
 */
@WebServlet("/GestionarClientesVendedor")
public class GestionarClientesVendedor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarClientesVendedor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        ITienda tienda = new Tienda();
        String[] message;
        
        String boton = request.getParameter("boton");
        
        System.out.println(boton);
        
        if(boton != null)
        	switch (boton) {
        	//Botones del jsp GestionarClientes
        	case "BN":
        		message = new String[13];
        		for(int i=0; i<message.length; i++)
        			message[i] = "";
        		request.setAttribute("message", message);
        		request.getRequestDispatcher("GestionCliente/NuevoClienteVendedor.jsp").forward(request, response);
        		break;
        	case "BD":
        		if(buscarCliente(request, response, tienda, session)) {
        			request.getRequestDispatcher("GestionCliente/InfoClientesVendedor.jsp").forward(request, response);
        		}else {
        			regresar(request, response, tienda, session);
        		}
        		break;
        		
        	case "BA":
        		if(buscarCliente(request, response, tienda, session)) {
        			message = new String[14];
        			for(int i=0; i<message.length; i++)
        				message[i] = "";
        			request.setAttribute("message", message);
        			request.getRequestDispatcher("GestionCliente/ActualizarClientesVendedor.jsp").forward(request, response);
        		}else {
        			regresar(request, response, tienda, session);
        		}
        		break;
        		
        	case "BE":
        		if(buscarCliente(request, response, tienda, session)) {
        			request.getRequestDispatcher("GestionCliente/EliminarClientesVendedor.jsp").forward(request, response);
        		}else {
        			regresar(request, response, tienda, session);
        		}
        		break;
        		
        		//Botones del jsp InfoClientes
        	case "DA":
        		message = new String[14];
        		for(int i = 0; i<message.length; i++)
        			message[i] = "";
        		request.setAttribute("message", message);
        		request.getRequestDispatcher("GestionCliente/ActualizarClientesVendedor.jsp").forward(request, response);
        		break;
        	case "DE":
        		request.getRequestDispatcher("GestionCliente/EliminarClienteVendedor.jsp").forward(request, response);
        		break;
        		
        		//Botones de accion
        	case "NC":
        		nuevoCliente(request, response, tienda, session);
        		break;
        		
        	case "AC":
        		try {
					actualizarCliente(request, response,tienda,session);
				} catch (ServletException | IOException | NegativeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
        	case "EC":
        		eliminarCliente(request, response,tienda,session);
        		break;
        	
        	case "C":
        		regresar(request, response,tienda,session);
        		break;
        	
        	default:
        		break;
        	}
        else {
        	regresar(request, response,tienda,session);
        }
        
    }
	protected boolean buscarCliente(HttpServletRequest request, HttpServletResponse response, ITienda tienda,HttpSession session) throws ServletException, IOException {
    	boolean result = false;
    	String message = "";
    	String numTarjeta = request.getParameter("numTarjeta");
    	if(numTarjeta != null) {
    		try {
    			Optional<Cliente> cliente = ClienteDB.buscar(numTarjeta);
    			if(cliente.isPresent()) {
    				session.setAttribute("cliente", cliente.get());
    				result = true;
    			}else {
    				String mensaje = "Cliente no encontrado";
    				request.setAttribute("message", mensaje);
    				regresar(request, response, tienda, session);
    			}
    		} catch (SQLException | NegativeException | LengthException | PalabraException | CaracterExcepcion
    				| CeroException | RangoException e) {
    			e.printStackTrace();
    			String messages = "Ha ocurrido un problema de conexion";
    			request.setAttribute("message", messages);
    			request.getRequestDispatcher("index.jsp").forward(request, response);
			}
    	}else {
    		
    		message = "No se pudo buscar al cliente";
    		request.setAttribute("message", message);
    		regresar(request, response, tienda, session);
    		
    	}
    	return result;
	}
	
	protected void regresar(HttpServletRequest request, HttpServletResponse response, ITienda tienda,HttpSession session) throws ServletException, IOException {
		try {
			session.setAttribute("clientes", tienda.getClientes());
			request.getRequestDispatcher("GestionCliente/ClientesVendedor.jsp").forward(request, response);
		} catch (SQLException | LengthException | NegativeException | PalabraException | CaracterExcepcion | CeroException | RangoException e) {
			
			e.printStackTrace();
			String messages = "Ha ocurrido un problmea de conexion";
			request.setAttribute("messages", messages);
			request.getRequestDispatcher("Index.jsp").forward(request, response);
		}
	}
	
	protected void nuevoCliente(HttpServletRequest request, HttpServletResponse response, ITienda tienda,HttpSession session) throws ServletException, IOException {
		boolean crear = true;
		String[] message = new String[14];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Direccion direccion = null;
		Cliente cliente = null;
		
		String primerNombre = request.getParameter("Nombre"); //0
		String segundoNombre = request.getParameter("SegundoNombre");//1
		String apellidoPaterno = request.getParameter("ApellidoPaterno");//2
		String apellidoMaterno = request.getParameter("ApellidoMaterno");//3
		int edad = 0;
		try {
			edad = Integer.parseInt(request.getParameter("Edad"));//4
		} catch (NumberFormatException e) {
			message[4] = "No ha ingresado una edad"; 
		}
		String numeroTelefono = request.getParameter("NumeroTelefono");//5
		String calle = request.getParameter("Calle");//6
		String numExterior = request.getParameter("NumExterno");//7
		String numInterior = request.getParameter("NumInterno");//8
		String colonia = request.getParameter("Colonia");//9
		String ciudad = request.getParameter("Alcaldia");//10
		String estado = request.getParameter("Estado");//11
		String codigoPostal = request.getParameter("CodigoPostal");//12
		
		//Creamos la direccion
		direccion = new Direccion();
		try {
			direccion.setCalle(calle.toUpperCase());
		} catch (PalabraException e) {
			message[6] = e.getMessage();
		}
		try {
			direccion.setNumExterior(numExterior.toUpperCase());
		} catch (CaracterExcepcion e) {
			message[7] = e.getMessage();
		}
		try {
			direccion.setNumInterior(numInterior.toUpperCase());
		} catch (CaracterExcepcion e) {
			message[8] = e.getMessage();
		}
		try {
			direccion.setColonia(colonia.toUpperCase());
		} catch (PalabraException e) {
			message[9] = e.getMessage();
		}
		try {
			direccion.setCiudad(ciudad.toUpperCase());
		} catch (PalabraException e) {
			message[10] = e.getMessage();
		}
		try {
			direccion.setEstado(estado.toUpperCase());
		} catch (PalabraException e) {
			message[11] = e.getMessage();
		}
		try {
			direccion.setCodigoPostal(codigoPostal.toUpperCase());
		} catch (CaracterExcepcion e) {
			message[12] = e.getMessage();
			e.printStackTrace();
		} catch (LengthException e) {
			message[12] = e.getMessage();
		}
		//Creamos la persona 
		try {
			cliente = new Cliente();
			try {
				cliente.setPrimerNombre(primerNombre.toUpperCase());
			} catch (PalabraException e) {
				message[0] = e.getMessage();
			}
			try {
				cliente.setSegundoNombre(segundoNombre.toUpperCase());
			} catch (PalabraException e) {
				message[1] = e.getMessage();
			}
			try {
				cliente.setApellidoPaterno(apellidoPaterno.toUpperCase());
			} catch (PalabraException e) {
				message[2] = e.getMessage();
			}
			try {
				cliente.setApellidoMaterno(apellidoMaterno.toUpperCase());
			} catch (PalabraException e) {
				message[3] = e.getMessage();
			}
			try {
				cliente.setEdad(edad);
			} catch (NegativeException e) {
				message[4] = e.getMessage();
			} catch (CeroException e) {
				message[4] = e.getMessage();
			} catch (RangoException e) {
				message[4] = e.getMessage();
			}
			try {
				cliente.setNumeroTelefono(numeroTelefono);
			} catch (LengthException e) {
				message[5] = e.getMessage();
			} catch (CaracterExcepcion e) {
				message[5] = e.getMessage();
			}
			
		} catch (SQLException e) {
			
		}
		
		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {
			try {
				String mensaje = "";
				cliente.setDireccion(direccion);
				
				if(ClienteDB.guardar(cliente)) {
					mensaje = "Se creado correctamente al cliente con número de tarjeta: " + cliente.getNumTarjeta();
					request.setAttribute("message", mensaje);
					regresar(request, response, tienda,session);
				}else {
					mensaje = "No se pudo crear al cliente";
					request.setAttribute("message", mensaje);
					regresar(request, response, tienda,session);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				String messages = "Ha ocurrido un problema de conexión";
				request.setAttribute("message", messages);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionCliente/NuevoClienteVendedor.jsp").forward(request, response);
		}
	}
	
	protected void actualizarCliente(HttpServletRequest request, HttpServletResponse response, ITienda tienda,HttpSession session) throws ServletException, IOException, NegativeException {
		boolean crear = true;
		String[] message = new String[14];
		for(int i=0; i<message.length; i++)
			message[i] = "";
		Cliente cliente = new Cliente((Cliente) session.getAttribute("cliente"));
		Direccion direccion = new Direccion(cliente.getDireccion());

		String primerNombre = request.getParameter("Nombre"); //0
		String segundoNombre = request.getParameter("SegundoNombre");//1
		String apellidoPaterno = request.getParameter("ApellidoPaterno");//2
		String apellidoMaterno = request.getParameter("ApellidoMaterno");//3
		String edadS = request.getParameter("Edad");
		int edad = 0;
		if(!edadS.equals("")) {
			try {
				edad = Integer.parseInt(edadS);//4
			} catch (NumberFormatException e) {
				message[4] = "No ha ingresado una edad"; 
			}
		}
		String numeroTelefono = request.getParameter("NumeroTelefono");//5
		String calle = request.getParameter("Calle");//6
		String numExterior = request.getParameter("NumExterno");//7
		String numInterior = request.getParameter("NumInterno");//8
		String colonia = request.getParameter("Colonia");//9
		String ciudad = request.getParameter("Alcaldia");//10
		String estado = request.getParameter("Estado");//11
		String codigoPostal = request.getParameter("CodigoPostal");//12
		String puntosS = request.getParameter("Puntos");
		int puntos = -1;
		if(!puntosS.equals("")) {
			try {
				puntos = Integer.parseInt(puntosS);//13
			} catch (NumberFormatException e) {
				message[13] = "No ha ingresado un cantidad"; 
			}
		}
		
		//Creamos la direccion
		try {
			if(!primerNombre.equals(""))
				direccion.setCalle(calle.toUpperCase());
		} catch (PalabraException e) {
			message[6] = e.getMessage();
		}
		try {
			if(!primerNombre.equals(""))
				direccion.setNumExterior(numExterior.toUpperCase());
		}catch (CaracterExcepcion e) {
			message[7] = e.getMessage();
		}
		try {
			if(!primerNombre.equals(""))
				direccion.setNumInterior(numInterior.toUpperCase());
		} catch (CaracterExcepcion e) {
			message[8] = e.getMessage();
		}
		try {
			if(!primerNombre.equals(""))
				direccion.setColonia(colonia.toUpperCase());
		} catch (PalabraException e) {
			message[9] = e.getMessage();
		}
		try {
			if(!primerNombre.equals(""))
				direccion.setCiudad(ciudad.toUpperCase());
		}catch (PalabraException e) {
			message[10] = e.getMessage();
		}
		try {
			if(!primerNombre.equals(""))
				direccion.setEstado(estado.toUpperCase());
		} catch (PalabraException e) {
			message[11] = e.getMessage();
		}
		try {
			if(!primerNombre.equals(""))
				direccion.setCodigoPostal(codigoPostal.toUpperCase());
		} catch (CaracterExcepcion e) {
			message[12] = e.getMessage();
		} catch (LengthException e) {
			message[12] = e.getMessage();
		}
		
		//Datos personales
		try {
			if(!primerNombre.equals(""))
				cliente.setPrimerNombre(primerNombre.toUpperCase());
		} catch (PalabraException e) {
			message[0] = e.getMessage();
			// TODO: handle exception
		}
		try {
			if(!segundoNombre.equals(""))
				cliente.setSegundoNombre(segundoNombre.toUpperCase());
		} catch (PalabraException e) {
			message[1] = e.getMessage();
		}
		try {
			if(!apellidoPaterno.equals(""))
				cliente.setApellidoPaterno(apellidoPaterno.toUpperCase());
		} catch (PalabraException e) {
			message[2] = e.getMessage();
		}
		try {
			if(!apellidoMaterno.equals(""))
				cliente.setApellidoMaterno(apellidoMaterno.toUpperCase());
		} catch (PalabraException e) {
			message[3] = e.getMessage();
		}
		try {
			if(!edadS.equals(""))
				cliente.setEdad(edad);
		} catch (NegativeException e) {
			message[4] = e.getMessage();
		} catch (CeroException e) {
			message[4] = e.getMessage();
		} catch (RangoException e) {
			message[4] = e.getMessage();
		}
		try {
			if(!numeroTelefono.equals(""))
				cliente.setNumeroTelefono(numeroTelefono);
		} catch (LengthException e) {
			message[5] = e.getMessage();
		} catch (CaracterExcepcion e) {
			message[5] = e.getMessage();
		}
		
		//Creamos al cliente
		try {
			if(!puntosS.equals(""))
				cliente.setPuntos(puntos);
		} catch (NegativeException e) {
			message[13] = e.getMessage();
		}
		

		for(String s: message) {
			if(!s.equals("")) {
				crear = false;
				break;
			}
		}
		
		if(crear) {	
			try {
				String mensaje = "";
				cliente.setDireccion(direccion);
				
				if(ClienteDB.actualizar(cliente)) {
					mensaje = "Se actualizaron correctamente los detos del cliente con número de tarjeta: " + cliente.getNumTarjeta();
					request.setAttribute("message", mensaje);
					regresar(request, response, tienda,session);
				}else {
					mensaje = "No se pudo actualizar al cliente";
					request.setAttribute("message", mensaje);
					regresar(request, response, tienda,session);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				String messages = "Ha ocurrido un problema de conexión";
				request.setAttribute("message", messages);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else {
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionVendedor/ActualizarClientesVendedor.jsp").forward(request, response);
	}
		
  }
	
	protected void eliminarCliente(HttpServletRequest request, HttpServletResponse response, ITienda tienda,HttpSession session) throws ServletException, IOException {
		Cliente cliente = (Cliente) session.getAttribute("cliente");
		String message; 
		System.out.println("entro funcio");
		try {
			if(ClienteDB.eliminar(cliente.getNumTarjeta())) {
				message = "Se ha eliminado correctamente al cliente con número de tarjeta: " + cliente.getNumTarjeta();
				request.setAttribute("message", message);
				regresar(request, response, tienda,session);
			}else {
				message = "No se pudo eliminar al cliente";
				request.setAttribute("message", message);
				regresar(request, response, tienda,session);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			String messages = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", messages);
			request.getRequestDispatcher("index.jsp").forward(request, response);
	}
  }
}


