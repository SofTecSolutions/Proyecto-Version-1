package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import general.exception.CaracterExcepcion;
import general.exception.CeroException;
import general.exception.FechaException;
import general.exception.LengthException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.exception.ProductoException;
import general.exception.RangoException;
import gestionClientes.modelo.Cliente;
import gestionClientes.modelo.ClienteDB;
import gestionClientes.modelo.ClienteDB;
import gestionArticulos.modelo.Articulo;
import gestionArticulos.modelo.ArticuloDB;
import gestionVendedores.modelo.Vendedor;
import gestionVentas.modelo.IProducto;
import gestionVentas.modelo.Venta;
import gestionVentas.modelo.VentaDB;
import gestionVentas.modelo.VentaDB;


/**
 * Servlet implementation class GestionarVentas
 */
@WebServlet("/GestionarVentas")
public class GestionarVentas extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionarVentas() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        
        String boton = request.getParameter("boton");
        
        if(boton != null) {
        	/* CV - FUNCION COMPLETAR COMPRA
             * EV - FUNCION CREAR NUEVA VENTA
             * 
             * AP - FUNCION AGREGAR PRODUCTO
             * EP - FUNCION QUITAR PRODUCTO
             * 
             * AD - FUNCION QUE APLICA UN DESCUENTO
             * TV - FUNCION QUE FINALIZA Y ALMACENA LA VENTA
             * 
             * 
             * */
        	switch (boton) {
        	
        	case "CV":
        		completarVenta(request,response,session);
        		break;
        		
        	case "EV":
        		Venta venta;
        		try {
        			venta = new Venta();
        			session.setAttribute("venta", venta);
        			request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
        		} catch (SQLException e) {
					e.printStackTrace();
					String message = "Ha ocurrido un problmea de conexion";
					request.setAttribute("message", message);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
        		break;
        		
        	case "AP":
        		agregarProducto(request, response,session);
        		break;
        		
        	case "EP":
        		eliminarProducto(request, response, session);
        		break;
        		
        	case "TV":
        		try {
        			terminarVenta(request, response, session);
        		} catch (NegativeException e) {
					e.printStackTrace();
					String message = "Ha ocurrido un problema de conexion";
					request.setAttribute("message", message);
					request.getRequestDispatcher("index.jsp").forward(request, response);
				}
        		break;
        		
        	case "AD":
        		aplicarDescuento(request, response, session);
        		break;
        		
        	case "":
        		
        		break;
        		
        	default:
        		break;
        	}
            }else {
            	Venta venta;
            	try {
            		venta = new Venta();
            		session.setAttribute("venta", venta);
            		request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
            	} catch (SQLException e) {
					e.printStackTrace();
					String message = "Ha ocurrido un problema de conexion";
					request.setAttribute("message", message);
					request.getRequestDispatcher("index.jsp").forward(request, response);
        	}
        }
	}
	
	protected void agregarProducto(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException {
			Venta venta = (Venta) session.getAttribute("venta");
			if(venta != null)
				venta = new Venta(venta);
			String id = request.getParameter("id");
			try {
				Optional<Articulo> articulo = ArticuloDB.buscar(id);
				
				if(articulo.isPresent()) {
					venta.agregarArticulo(articulo.get());
					session.setAttribute("venta", venta);
					request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);					
				}else {
					String message = "Producto no encontrado";
					request.setAttribute("message", message);
					request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
					
				}
				
			} catch (SQLException | PalabraException | FechaException | NegativeException e) {
				e.printStackTrace();
				String message = "Ha ocurrido un problema de conexion";
				request.setAttribute("message", message);
				request.getRequestDispatcher("index.jsp").forward(request, response);
				
			}
			
	  }
	
	protected void eliminarProducto(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException  {
		Venta venta = (Venta) session.getAttribute("venta");
		if(venta != null)
			venta = new Venta(venta);
		String id = request.getParameter("id");
		try {
			Optional<Articulo> articulo = ArticuloDB.buscar(id);
			
			if(articulo.isPresent()) {
				try {
					venta.eliminarArticulo(articulo.get());
					session.setAttribute("venta", venta);
					request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
				} catch (ProductoException e) {
					e.printStackTrace();
					String message = e.getMessage() + "en la canasta";
					request.setAttribute("message", message);
					request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
				} catch (CeroException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}else {
				String message = "Producto no encontrado";
				request.setAttribute("message", message);
				request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
				
			}
			
		} catch (SQLException | PalabraException | FechaException | NegativeException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexion";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		
	}
	
	protected void completarVenta(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException {
		Venta venta = (Venta) session.getAttribute("venta");
		if(venta != null)
			venta = new Venta(venta);
		String message = "";
		int cont = 0;
		Iterator<IProducto> productos = venta.getProductos();
		while(productos.hasNext()) {
			productos.next();
			cont++;
		}
		
		if(cont>0) {
			venta.generarFechaHora();
				session.setAttribute("venta", venta);
			request.getRequestDispatcher("GestionVenta/InfoVendedor.jsp").forward(request, response);
		}else {
			message = "Debe tener por lo menos un producto seleccionado";
			request.setAttribute("message", message);
			request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
		}
		
	}
	
	protected void aplicarDescuento(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException  {
		Venta venta = (Venta) session.getAttribute("venta");
		if(venta != null)
			venta = new Venta(venta);
		String numTarjeta = request.getParameter("numTarjeta");
		try {
			Optional<Cliente> cliente = ClienteDB.buscar(numTarjeta);
			
			if(cliente.isPresent()) {
				session.setAttribute("cliente", cliente.get());
				venta.aplicarDescuento(cliente.get().getDescuento());
				session.setAttribute("venta", venta);
				session.setAttribute("numT", cliente.get());
				request.getRequestDispatcher("GestionVenta/InfoVentaVendedor.jsp").forward(request, response);
			}else {
				String message = "Cliente no encontrado";
				request.setAttribute("message", message);
				session.removeAttribute("numT");
				request.getRequestDispatcher("GestionVenta/InfoVentaVendedor.jsp").forward(request, response);
			}
		} catch (SQLException | PalabraException | CaracterExcepcion | LengthException | NegativeException
				| CeroException | RangoException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
	
	protected void terminarVenta(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException, NegativeException {
		Vendedor vendedor = (Vendedor) session.getAttribute("vendedor");
		if(vendedor != null)
			vendedor = new Vendedor(vendedor);
		Cliente cliente = (Cliente) session.getAttribute("numT");
		if(cliente != null)
			cliente = new Cliente(cliente);
		Venta venta = (Venta) session.getAttribute("venta");
		if(venta != null)
			venta = new Venta(venta);
		
		venta.generarFechaHora();
		
		try {
			if(VentaDB.guardar(venta, vendedor.getNumEmpleado())) {
				if(cliente!=null)
					ClienteDB.actualizarPuntos(cliente);
				String message = "Venta completada: " + venta.getFolio();
				request.setAttribute("message", message);
				venta = new Venta();
				session.setAttribute("venta", venta);
				session.removeAttribute("cliente");
				request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
			}else {
				String message = "Error al hacer la venta";
				request.setAttribute("message", message);
				venta = new Venta();
				session.setAttribute("venta", venta);
				request.getRequestDispatcher("GestionVenta/Vendedor.jsp").forward(request, response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			String message = "Ha ocurrido un problema de conexión";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(request, response);
	}
  }
	
	protected void a(HttpServletRequest request, HttpServletResponse response,HttpSession session) throws ServletException, IOException  {
		
	}
}

