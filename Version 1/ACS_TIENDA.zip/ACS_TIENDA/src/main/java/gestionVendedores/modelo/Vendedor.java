package gestionVendedores.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import general.exception.*;
import general.modelo.Direccion;
import general.modelo.IDireccion;
import general.modelo.Persona;
import gestionVentas.modelo.IVenta;
import gestionVentas.modelo.Venta;
import gestionVentas.modelo.VentaDB;

public class Vendedor extends Persona implements IVendedorCompleto{
	private String numEmpleado;
	private double sueldo;
	private Usuario usuario = null;
	private List<Venta> ventas;
	
	private final int LENGTH_NUM_EMPLEADO = 5;
	private final int MAX_EMPLEADOS  = (int) Math.pow(10, LENGTH_NUM_EMPLEADO);
	
	//Metodo de vendedor
	
	public Vendedor() throws SQLException {
		this.numEmpleado = generarNumEmpleado();
		this.ventas = new ArrayList<Venta>();
	}
	
	protected Vendedor(String numEmpleado, String correo, Persona datosPersonales) {
		super(datosPersonales);
		this.numEmpleado = numEmpleado;
		this.usuario = new Usuario(correo);
		this.ventas = new ArrayList<Venta>();
	
	}
	
	public Vendedor(Vendedor vendedor) {
		//Datos de persona 
		primerNombre = vendedor.getPrimerNombre();
		segundoNombre = vendedor.getSegundoNombre();
		apellidoPaterno = vendedor.getApellidoPaterno();
		apellidoMaterno = vendedor.getApellidoMaterno();
		edad = vendedor.getEdad();
		numeroTelfono = vendedor.getNumeroTelefono();
		//Datos de direccion
		direccion = new Direccion(vendedor.direccion);
		//Datos de vendedor
		numEmpleado = vendedor.getNumEmpleado();
		sueldo = vendedor.getSueldo();
		usuario = new Usuario(vendedor.usuario);
		this.ventas = new ArrayList<Venta>();
	}
	
	public void setSueldo(double sueldo) throws NegativeException{
		if(sueldo >= 0)
			this.sueldo = sueldo;
		else 
			throw new NegativeException();
	}
	
	public void setPassword(String password) throws LengthException{
		this.usuario.setPassword(password);
	}
	
	private String generarNumEmpleado() throws SQLException{
		String numEmpleado = "";
		int numEmpleadoI = 0;
		do {
			numEmpleadoI = (int) (Math.random() * MAX_EMPLEADOS);
			
			if(numEmpleadoI >= MAX_EMPLEADOS)
				numEmpleadoI = MAX_EMPLEADOS - 1;
			
			numEmpleado = "" + numEmpleadoI;
			
			while(numEmpleado.length() < LENGTH_NUM_EMPLEADO) {
				numEmpleado = "0" + numEmpleado;
			}
		} while (VendedorBD.existe(numEmpleado));
		return numEmpleado;
	}
	
	public void generarCorreo() throws SQLException, LengthException{
		String correo = primerNombre.toLowerCase().replaceAll(" ", ".") + "." + apellidoPaterno.toLowerCase().replaceAll(" ", ".");
		if(VendedorBD.existeCorreo(correo + "@tiendaACS.com")) {
			correo += "." + apellidoMaterno.toLowerCase().replaceAll(" ", ".");
			if(VendedorBD.existeCorreo(correo + "@tiendaACS.com")) {
				correo += "." + numEmpleado;
			}
		}
		this.usuario = new Usuario(correo + "@tiendaACS.com");
		this.usuario.setPassword("hola123" + numEmpleado);
	}
	
public void cargarVentas() throws SQLException, FechaException, PalabraException, NegativeException {
	List<Venta> ventas = VentaDB.buscarVentas(numEmpleado);
	this.ventas = new ArrayList<Venta>();
	
	for(Venta v: ventas) {
		this.ventas.add(new Venta(v));
	}
}
	//Metodos de IVendedorCompleto


public Iterator<IVenta> getVentas() throws SQLException, FechaException, PalabraException, NegativeException {
	cargarVentas();
	List<IVenta> ventas = new ArrayList<IVenta>();
	for(Venta v: this.ventas)
		ventas.add(v);
	return ventas.iterator();
}

	public String getPassword() {
		return this.usuario.getPassword();
	}
	
	//Metodos de IVendedor
	
	public String getNumEmpleado() {
		return numEmpleado;
	}
	public double getSueldo() {
		return sueldo;
	}
	public String getCorreo() {
		return usuario.getCorreo();
	}
	
	
	//Metodos de IPersona
	
	public String getPrimerNombre() {
		return primerNombre;
	}
	
	public String getSegundoNombre() {
		return segundoNombre;
	}
	
	public String getApellidoPaterno() {
		return apellidoPaterno;
	}
	public String getApellidoMaterno() {
		return apellidoMaterno;
	}
	public int getEdad() {
		return edad;
	}
	
	public String getNumeroTelefono() {
		return numeroTelfono;
	}
	public IDireccion getDireccion() {
		return direccion;
	}
	
	public String nombreCompleto() {
		String s = "";
		if(!apellidoPaterno.equals(""))
			s += apellidoPaterno;
		if(!apellidoMaterno.equals(""))
			s += apellidoMaterno;
		if(!primerNombre.equals(""))
			s += primerNombre;
		if(!segundoNombre.equals(""))
			s += segundoNombre;
		return s;
	}
	

}
