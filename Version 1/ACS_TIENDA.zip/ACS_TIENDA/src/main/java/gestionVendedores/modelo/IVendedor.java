package gestionVendedores.modelo;

import general.modelo.IPersona;

public interface IVendedor extends IPersona {
	public String getNumEmpleado();
	public double getSueldo();
	public String getCorreo();

}