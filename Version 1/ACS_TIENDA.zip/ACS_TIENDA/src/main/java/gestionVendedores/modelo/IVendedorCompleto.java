package gestionVendedores.modelo;

import java.sql.SQLException;
import java.util.Iterator;

import general.exception.FechaException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import gestionVentas.modelo.IVenta;

public interface IVendedorCompleto extends IVendedor {
	public Iterator<IVenta> getVentas() throws SQLException, FechaException, PalabraException, NegativeException;
	public String getPassword();
}
