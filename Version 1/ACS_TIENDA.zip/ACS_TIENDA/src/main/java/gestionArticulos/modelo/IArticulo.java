package gestionArticulos.modelo;

import java.util.Iterator;

public interface IArticulo {
	public String getId();
	public String getNombre();
	public double getPrecio();
	public int getNumeroArticulos();
	

}
