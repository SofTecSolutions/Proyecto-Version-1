package gestionArticulos.modelo;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import general.exception.*;

public class Articulo implements IArticulo{
	private String id;
	private String nombre;
	private double precio;
	private int numArticulos;
	
	private final int LENGTH_ID = 3;
	private final int MAX_ARTICULOS = (int) Math.pow(10, LENGTH_ID);
	
	
	//Metodos de Articulo
	
	public Articulo() throws SQLException{
		this.id = generarId();
		numArticulos = 0;
	}
	
	protected Articulo(String id) {
		this.id = id;
	}
	
	public Articulo(Articulo articulo) {
		this.id = articulo.getId();
		this.nombre = articulo.getNombre();
		this.precio = articulo.getPrecio();
		this.numArticulos = articulo.numArticulos;
	
	}
	
	public void setNombre(String nombre) throws PalabraException{
		if(nombre.matches("^[A-ZÁÉÍÓÚÜÑ0-9\\.]{1,50}([\\s][A-ZÁÉÍÓÚÑ0-9\\.]{1,50}){0,9}"))
			this.nombre = nombre;
		else 
			throw new PalabraException();
	}
	
	public void setPrecio(double precio) throws NegativeException{
		if(precio >= 0)
			this.precio = precio;
		else
			throw new NegativeException();
	}
	
	public void setNumArticulos(int numArticulos) throws NegativeException{
		if(numArticulos >= 0)
			this.numArticulos = numArticulos;
		else
			throw new NegativeException();
	}
	
	private String generarId() throws SQLException{
		String id = "";
		do {
			int idI = (int) (Math.random() * MAX_ARTICULOS);
			if(idI >= MAX_ARTICULOS)
				idI = MAX_ARTICULOS - 1;
			
			id = "" + idI;
			
			while(id.length() < LENGTH_ID) {
				id = "0" + id;
			}
		} while(ArticuloDB.existe(id));
		return id;
	}
	
	
	//Metodos de IArticulo
	
	@Override
	public String getId() {
		return id;
	}
	
	@Override
	public String getNombre() {
		return nombre;
	}
	
	@Override
	public double getPrecio() {
		return precio;
	}
	
	@Override
	public int getNumeroArticulos() {
		return numArticulos;
	}
}
