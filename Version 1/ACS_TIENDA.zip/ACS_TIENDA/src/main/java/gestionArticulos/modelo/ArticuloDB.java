package gestionArticulos.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import general.exception.FechaException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.modelo.AdminBD;
import gestionVentas.modelo.Producto;

public class ArticuloDB {
	
	public static boolean existe(String id) throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			try {
				st = conexion.createStatement();
				comSQL = "select * from medicamento where id = '" + id + "';";
				rs = st.executeQuery(comSQL);
				while(rs.next()) {
					cont += 1;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					conexion.close();
				}catch (SQLException e2) {
					// TODO: handle exception
				}
			}
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}
	
	public static Optional<Articulo> buscar(String id) throws SQLException, PalabraException, FechaException, NegativeException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Articulo articulo = null;
		
		String nombre = "";
		double precio = 0;
		int numArticulos = 0;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from medicamento where id = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				id = rs.getString("id");
				nombre = rs.getString("nombre");
				precio = rs.getDouble("precio");
				
				articulo = new Articulo(id);
				articulo.setNombre(nombre);
				articulo.setPrecio(precio);
			}
			if(articulo != null) {
				comSQL = "select * from articulo_existencia where id = '" + articulo.getId() + "';";
				rs = st.executeQuery(comSQL);
				
				while(rs.next()) {
					numArticulos = rs.getInt("num_articulos");
					
					articulo.setNumArticulos(numArticulos);
				}
			}
			conexion.close();
		}
		
		return Optional.ofNullable(articulo);
	}
	public static boolean actualizar(Articulo articulo) throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update articulo set nombre = '" + articulo.getNombre() + "'where id ='" + articulo.getId() + "';";
			cont += st.executeUpdate(comSQL);
			comSQL = "update articulo set precio = " + articulo.getPrecio() + " where id = '" + articulo.getId() + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont >= 1) {
				conexion.commit();
				respuesta = true;
			}else
				conexion.rollback();
			
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean actualizarExistencia(Articulo articulo) throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "update articulo_existencia set num_articulos =" + articulo.getNumeroArticulos() + "where id= '" + articulo.getId() +"';";
			cont += st.executeUpdate(comSQL);
			
			if(cont >= 1) {
				conexion.commit();
				respuesta = true;
			}else
				conexion.rollback();
			
			conexion.close();
		}
		return respuesta;
	}
	public static boolean eliminar(String id) throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "delete from venta_prodcuto where id_articulo ='" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from articulo_existencia where id = '" + id + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from articulo where id = '"+ id + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont >= 1) {
				respuesta = true;
				conexion.commit();
			}else
				conexion.rollback();
			
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean guardar(Articulo articulo) throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			comSQL = "insert into articulo values ('" + articulo.getId() +"' , '" + articulo.getNombre() +
					 "' , " + articulo.getPrecio() +");";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "insert into articulo_existencia values ('" + articulo.getId() + "' , " + articulo.getNumeroArticulos() + ");";
			cont += st.executeUpdate(comSQL);
			
			if(cont >=1)
				respuesta = true;
			
			conexion.close();
		}
		
		return respuesta;
	}
	public static List<Articulo> buscarArticulo() throws SQLException, PalabraException, FechaException, NegativeException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Articulo> articulos = new ArrayList<Articulo>();
		Articulo articulo = null;
		
		String id = "";
		String nombre = "";
		double precio = 0;
		int numArticulos = 0;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from articulo; ";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				id = rs.getString("id");
				nombre = rs.getString("nombre");
				precio = rs.getDouble("precio");
				
				articulo = new Articulo(id);
				articulo.setNombre(nombre);
				articulo.setPrecio(precio);
				
				articulos.add(articulo);
			}
			for(Articulo a: articulos) {
				comSQL = "select * from articulo_existencia where id = '" + a.getId() + "';";
				rs = st.executeQuery(comSQL);
				
				while(rs.next()) {
					numArticulos = rs.getInt("num_articulos");
					
					a.setNumArticulos(numArticulos);
				}
			}
			conexion.close();
		}
		return articulos;
	}
	
	public static List<Producto> buscarProductos(String id) throws FechaException, SQLException, PalabraException, NegativeException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Producto> prodcutos = new ArrayList<Producto>();
		Producto prodcuto = null;
		Articulo articulo = null;
		
		String idC = "";
		int numArticulos = 0;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from venta_producto where folio = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				idC = rs.getString("id_articulo");
				numArticulos = rs.findColumn("cantidad");
				
				articulo = buscar(idC).get();
				
				prodcuto = new Producto(articulo);
				
				for(int i=1; i<=numArticulos; i++)
					prodcutos.add(prodcuto);
			}
			
			conexion.close();
		}
		
		return prodcutos;
	}

}
