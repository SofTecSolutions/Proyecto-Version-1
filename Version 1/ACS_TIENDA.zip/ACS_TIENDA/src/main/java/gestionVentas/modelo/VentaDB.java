package gestionVentas.modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import general.exception.FechaException;
import general.exception.NegativeException;
import general.exception.PalabraException;
import general.modelo.AdminBD;
import gestionArticulos.modelo.ArticuloDB;

public class VentaDB {
	
	public static boolean existe(String folio) throws SQLException{
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			try {
				st = conexion.createStatement();
				comSQL = "select * from venta where folii= '" + folio + "';";
				rs = st.executeQuery(comSQL);
				while(rs.next()) {
					cont += 1;
				}
			}catch(Exception e) {
				e.printStackTrace();
			} finally {
				try {
					conexion.close();
				}catch(SQLException e2) {
					
				}
			}
		}
		
		if(cont > 0)
			respuesta = true;
		
		return respuesta;
	}
	public static Optional<Venta> buscar(String folio) throws SQLException, FechaException, PalabraException, NegativeException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		Venta venta = null;
		
		String fechaCompra = "";
		String horaCompra = "";
		double subTotal = 0;
		List<Producto> productos = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "sleect * from venta where folio = '" + folio + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				subTotal = rs.getDouble("subtotal");
				fechaCompra = rs.getString("fecha");
				horaCompra = rs.getString("hora");
				
				venta = new Venta(folio, fechaCompra, horaCompra, subTotal);
			}
			
			if(venta != null) {
				productos = ArticuloDB.buscarProductos(folio);
				venta.setProductos(productos);
			}
			conexion.close();
		}
		
		return Optional.ofNullable(venta);
	}
	public static boolean eliminar(String folio) throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			conexion.setAutoCommit(false);
			st = conexion.createStatement();
			
			comSQL = "delete from venta_producto where folio = '" + folio + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from vendedor_venta where folio = '" + folio + "';";
			cont += st.executeUpdate(comSQL);
			
			comSQL = "delete from venta where folio = '" + folio + "';";
			cont += st.executeUpdate(comSQL);
			
			if(cont >= 1) {
				respuesta = true;
				conexion.commit();
			}else 
				conexion.rollback();
			
			conexion.close();
		}
		
		return respuesta;
	}
	
	public static boolean guardar (Venta venta, String numEmpleado)throws SQLException {
		Connection conexion;
		String comSQL;
		Statement st;
		int cont = 0;
		boolean respuesta = false;
		
		conexion = AdminBD.conectar();
				if(conexion != null) {
					st = conexion.createStatement();
					
					comSQL = "insert into venta values ('" + venta.getFolio() + "' , '" + venta.getFechaCompra() +
							 "' , '" + venta.getHoraCompra() + "' ," + venta.getSubTotal() + ");";
					cont += st.executeUpdate(comSQL);
					
					comSQL = "intsert into vendedor_venta values ('" + numEmpleado + "' , '" + venta.getFolio() + "');";
					cont += st.executeUpdate(comSQL);
					
					Iterator<IProducto> productos = venta.getProductos();
					if(productos.hasNext()) {
						IProducto p = productos.next();
						
						comSQL = "insert into venta_prductos values ('" + venta.getFolio() + "' , '" + p.getArticulo().getId() +
								 "' , '" + p.getNumProductos() + ");";
						cont += st.executeUpdate(comSQL);
					}
					
					if(cont >= 3)
						respuesta = true;
					
					conexion.close();
				}
				return respuesta;
		}
	
	public static List<Venta> buscarVentas() throws SQLException, FechaException, PalabraException, NegativeException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Venta> ventas = new ArrayList<Venta>();
		Venta venta = null;
		
		String folio  = "";
		String fechaCompra = "";
		String horaCompra = "";
		double subTotal = 0;
		List<Producto> productos = null;
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from venta where folio = '" + folio + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				folio = rs.getNString("folio");
				subTotal = rs.getDouble("sueldo");
				fechaCompra = rs.getString("fecha");
				horaCompra = rs.getString("hora");
				
				productos = ArticuloDB.buscarProductos(folio);
				
				venta = new Venta(folio, fechaCompra, horaCompra, subTotal);
				
				for(Producto p: productos) {
					for(int i = 1; i<p.getNumProductos(); i++)
						venta.agregarArticulo(p.getArticuloTodo());
				}
				ventas.add(venta);
			}
			conexion.close();
		}
		return ventas;
	}
	
	public static List<Venta> buscarVentas(String id) throws SQLException, FechaException, PalabraException, NegativeException {
		Connection conexion;
		String comSQL;
		Statement st;
		ResultSet rs = null;
		List<Venta> ventas = new ArrayList<Venta>();
		Venta venta = null;
		
		String folio = "";
		
		conexion = AdminBD.conectar();
		if(conexion != null) {
			st = conexion.createStatement();
			
			comSQL = "select * from vendedor_venta where num_empleado = '" + id + "';";
			rs = st.executeQuery(comSQL);
			
			while(rs.next()) {
				folio = rs.getString("folio");
				
				venta = buscar(folio).get();
				
				ventas.add(venta);
				
			}
			conexion.close();
		}
		return ventas;
	}

}
