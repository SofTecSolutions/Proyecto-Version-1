package gestionVentas.modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import general.exception.*;
import gestionArticulos.modelo.Articulo;

public class Venta implements IVenta{
	private String folio;
	private String fechaCompra;
	private String horaCompra;
	private double subTotal;
	private int descuento;
	private Map<String, Producto> articulos;
	
	private final int LENGTH_FOLIO = 6;
	private final int MAX_VENTAS = (int) Math.pow(10, LENGTH_FOLIO);
	
	//Metodos de venta
	
	public Venta() throws SQLException {
		this.folio = generarFolio();
		this.descuento = 0;
		this.subTotal = 0;
		this.fechaCompra = "";
		this.horaCompra = "";
		this.articulos = new HashMap<>();
	}
	
	protected Venta(String folio, String fechaCompra,String horaCompra, double subTotal ){
		this.folio = folio;
		this.fechaCompra = fechaCompra;
		this.horaCompra = horaCompra;
		this.subTotal = subTotal;
		this.articulos = new HashMap<>();
	}
	
	public Venta(Venta venta) {
		this.folio = venta.folio;
		this.fechaCompra = venta.fechaCompra;
		this.horaCompra = venta.horaCompra;
		this.subTotal = venta.subTotal;
		this.descuento = venta.descuento;
		this.articulos = new HashMap<>();
		
		for(Producto p: venta.articulos.values()) {
			this.articulos.put(p.getArticulo().getId(), new Producto(p));
		}
		
	}
	protected void setProductos(List<Producto> productos) {
		this.articulos = new HashMap<>();
		
		for(Producto p: productos) {
			this.articulos.put(p.getArticulo().getId(), new Producto(p));
		}
	}
	
	public void agregarArticulo(Articulo articulo) {
		if(this.articulos.containsKey(articulo.getId())) {
			Producto p = this.articulos.get(articulo.getId());
			p.aumentar();
		}else
			this.articulos.put(articulo.getId(), new Producto(articulo));
		subTotal += articulo.getPrecio();
	}
	
	public void eliminarArticulo(Articulo articulo) throws ProductoException, CeroException{
		if(this.articulos.containsKey(articulo.getId())) {
			Producto p = this.articulos.get(articulo.getId());
			if(p.getNumProductos()== 1)
				this.articulos.remove(articulo.getId());
			else
				p.disminuir();
			subTotal -= articulo.getPrecio(); 
		}else
			throw new ProductoException();
	}
	
	public void aplicarDescuento(int descuento) throws NegativeException{
		if(descuento >= 0)
			this.descuento = descuento;
		else
			throw new NegativeException();
	}
	
	@SuppressWarnings("deprecation")
	public void generarFechaHora() {
		Date fecha = new Date();
		Calendar c = new GregorianCalendar();
		String cadena = "";
		
		//hora 
		if(fecha.getHours() < 10)
			cadena += "0";
		cadena += fecha.getHours() + ":";
		if(fecha.getMinutes() < 10)
			cadena += "0";
		cadena += fecha.getMinutes();
		this.horaCompra = cadena;
		
		
		//fecha	
		cadena = "";
		if(fecha.getDate() < 10)
			cadena += "0";
		cadena += fecha.getDate() + "/";
		if(fecha.getMonth()+1 < 10)
			cadena += "0";
		cadena += (fecha.getMonth()+1) + "/" +c.get(Calendar.YEAR);
		this.fechaCompra = cadena;
	}
	private String generarFolio() throws SQLException{
		String folio = "";
		do {
			int folioI = (int) (Math.random() * MAX_VENTAS);
			if(folioI >= MAX_VENTAS)
				folioI = MAX_VENTAS - 1;
			folio = "" + folioI;
			
			while(folio.length() < LENGTH_FOLIO) {
				folio = "0" + folio;
			}
		} while (VentaDB.existe(folio));
		return folio;
	}
	
	public boolean hayProductos() {
		return articulos.isEmpty();
	}
	
	//Metodos de IVenta
	
	@Override
	public String getFolio() {
		return folio;
	}
	@Override
	public String getFechaCompra() {
		return fechaCompra;
	}
	@Override
	public String getHoraCompra() {
		return horaCompra;
	}
	@Override
	public double getSubTotal() {
		double total = descuento;
		total /= 100.0;
		total *= subTotal;
		total = subTotal - total;
		return total;
	}
	@Override
	public int  getDescuento() {
		return descuento;
	}
	
	@Override
	public Iterator<IProducto> getProductos(){
		List<IProducto> productos = new ArrayList<IProducto>();
		
		for(Producto p: this.articulos.values()) {
			productos.add(new Producto(p));
		}
		
		return productos.iterator();
	}
}
