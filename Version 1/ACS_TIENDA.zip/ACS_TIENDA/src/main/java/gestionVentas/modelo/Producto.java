package gestionVentas.modelo;

import general.exception.CeroException;
import gestionArticulos.modelo.IArticulo;
import gestionArticulos.modelo.Articulo;

public class Producto implements IProducto {
	private int numProductos;
	private Articulo articulo;
	
	//Metodos de producto
	
	public Producto (Articulo articulo) {
		this.articulo = new Articulo(articulo);
		this.numProductos = 1;
	}
	
	public Producto(Producto producto) {
		this.numProductos = producto.getNumProductos();
		this.articulo = new Articulo(producto.articulo);
	}
	
	public void aumentar() {
		numProductos++;
	}
	
	public void disminuir() throws CeroException{
		if(numProductos-1 > 0)
			numProductos--;
		else
			throw new CeroException();
	}
	
	protected Articulo getArticuloTodo() {
		return articulo;
	}
	
	//Metodos de IProductos
	
	@Override
	public int getNumProductos() {
		return numProductos;
	}
	
	public IArticulo getArticulo() {
		return articulo;
	}

	@Override
	public double subTotal() {
		return numProductos * articulo.getPrecio();
	}
	

}
