package gestionVentas.modelo;

import gestionArticulos.modelo.IArticulo;

public interface IProducto {
	public int getNumProductos();
	public IArticulo getArticulo();
	public double subTotal();

}
